public class Ui {
    NotasAluno notas = new NotasAluno();
    Boletim boletim = new Boletim();
    public boolean rodar = true;

    String menu = "1 - Digitar notas\n2 - Exiba notas\n3 - Sair";
}
