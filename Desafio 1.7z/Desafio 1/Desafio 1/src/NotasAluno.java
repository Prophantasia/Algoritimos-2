public class NotasAluno {

    private double nota1;
    private double nota2;
    private double nota3;
    
    public void setNota1(double n1) {
        this.nota1 = n1;
    }

    public double getNota1() {
        return this.nota1;
    }
 
    public void setNota2(double n2) {
        this.nota2 = n2;
    }

    public double getNota2() {
        return this.nota2;
    }
    public void setNota3(double n3) {
        this.nota3 = n3;
    }

    public double getNota3() {
        return this.nota3;
    }
}